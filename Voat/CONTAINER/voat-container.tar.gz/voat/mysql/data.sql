CREATE DATABASE IF NOT EXISTS `voat` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `voat`;

CREATE TABLE Ad (
    ID int(11) NOT NULL,
    IsActive bit(1) DEFAULT 1 ,
    GraphicUrl varchar(100) NOT NULL,
    DestinationUrl text,
    Name varchar(100) NOT NULL,
    Description text NOT NULL,
    StartDate timestamp,
    EndDate datetime,
    Subverse varchar(50),
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ApiClient (
    ID int(11) NOT NULL,
    IsActive bit(1) DEFAULT 1 ,
    UserName varchar(100),
    AppName varchar(50) NOT NULL,
    AppDescription text,
    AppAboutUrl varchar(200),
    RedirectUrl varchar(200),
    PublicKey varchar(100) NOT NULL,
    privateKey varchar(100) NOT NULL,
    LastAccessDate timestamp,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP,
    ApiThrottlePolicyID int(11),
    ApiPermissionPolicyID int(11)
) ENGINE=MyISAM;

CREATE TABLE ApiCorsPolicy (
    ID int(11) NOT NULL,
    IsActive bit(1) NOT NULL,
    AllowOrigin varchar(100) NOT NULL,
    AllowMethods varchar(100) NOT NULL,
    AllowHeaders varchar(100) NOT NULL,
    AllowCredentials bit(1),
    MaxAge int(11),
    UserName varchar(100),
    Description text,
    CreatedBy varchar(100) NOT NULL,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ApiLog (
    ID int(11) NOT NULL,
    ApiClientID int(11) NOT NULL,
    Method varchar(10) NOT NULL,
    Url text NOT NULL,
    Headers text,
    Body text,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ApiPermissionPolicy (
    ID int(11) NOT NULL,
    Name varchar(100) NOT NULL,
    Policy text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ApiThrottlePolicy (
    ID int(11) NOT NULL,
    Name varchar(100) NOT NULL,
    Policy text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE Badge (
    ID varchar(50) NOT NULL,
    Graphic varchar(50) NOT NULL,
    Title text NOT NULL,
    Name varchar(50) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE BannedDomain (
    ID int(11) NOT NULL,
    Domain varchar(50) NOT NULL,
    CreatedBy varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Reason text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE BannedUser (
    ID int(11) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Reason text NOT NULL,
    CreatedBy varchar(50) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE Comment (
    ID int(11) NOT NULL,
    Votes int(11),
    UserName varchar(50) NOT NULL,
    Content text NOT NULL,
    CreationDate timestamp NOT NULL,
    LastEditDate timestamp,
    SubmissionID int(11) NOT NULL,
    UpCount bigint DEFAULT 1 NOT NULL,
    DownCount bigint DEFAULT 0,
    ParentID int(11),
    IsAnonymized bit(1) DEFAULT 0 ,
    IsDistinguished bit(1) DEFAULT 0 ,
    FormattedContent text,
    IsDeleted bit(1) DEFAULT 0 
) ENGINE=MyISAM;

CREATE TABLE CommentSaveTracker (
    ID int(11) NOT NULL,
    CommentID int(11) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE CommentVoteTracker (
    ID int(11) NOT NULL,
    CommentID int(11) NOT NULL,
    UserName varchar(50),
    VoteStatus int(11),
    CreationDate timestamp,
    IPAddress varchar(90)
) ENGINE=MyISAM;

CREATE TABLE ContentRemovalLog (
    CommentID int(11) NOT NULL,
    Moderator varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Reason text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE DefaultSubverse (
    Subverse varchar(20) NOT NULL,
    `Order` int(11) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE EventLog (
    ID int(11) NOT NULL,
    ParentID int(11),
    ActivityID varchar(50),
    UserName varchar(100),
    Origin varchar(20),
    `Type` text NOT NULL,
    Message text NOT NULL,
    Category text NOT NULL,
    Exception text,
    Data text,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE FeaturedSubverse (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    CreatedBy varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE Message (
    ID int(11) NOT NULL,
    CorrelationID varchar(36) NOT NULL,
    ParentID int(11),
    `Type` int(11) NOT NULL,
    Sender varchar(50) NOT NULL,
    SenderType int(11) NOT NULL,
    Recipient varchar(50) NOT NULL,
    RecipientType int(11) NOT NULL,
    Title text,
    Content text,
    FormattedContent text,
    Subverse varchar(20),
    SubmissionID int(11),
    IsAnonymized bit(1) NOT NULL,
    ReadDate timestamp,
    CreatedBy varchar(50),
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ModeratorInvitation (
    ID int(11) NOT NULL,
    CreatedBy varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Recipient varchar(50) NOT NULL,
    Subverse varchar(20) NOT NULL,
    Power int(11) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE SessionTracker (
    SessionID varchar(90) NOT NULL,
    Subverse varchar(20) NOT NULL,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP NOT NULL
) ENGINE=MyISAM;

CREATE TABLE StickiedSubmission (
    SubmissionID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE Submission (
    ID int(11) NOT NULL,
    IsArchived bit(1) DEFAULT 0 ,
    Votes int(11),
    UserName varchar(50) NOT NULL,
    Content text,
    CreationDate timestamp NOT NULL,
    `Type` int(11) NOT NULL,
    Title varchar(200),
    Rank double precision DEFAULT 0.0 NOT NULL,
    Subverse varchar(20),
    UpCount bigint DEFAULT 1 NOT NULL,
    DownCount bigint DEFAULT 0 NOT NULL,
    Thumbnail varchar(40),
    LastEditDate timestamp,
    FlairLabel varchar(50),
    FlairCss varchar(50),
    Views double precision DEFAULT 1.0 NOT NULL,
    IsDeleted bit(1) DEFAULT 0 ,
    IsAnonymized bit(1) DEFAULT 0 ,
    RelativeRank double precision DEFAULT 0.0 NOT NULL,
    Url text,
    FormattedContent text
) ENGINE=MyISAM;

CREATE TABLE SubmissionRemovalLog (
    SubmissionID int(11) NOT NULL,
    Moderator varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Reason text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE SubmissionSaveTracker (
    ID int(11) NOT NULL,
    SubmissionID int(11) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE SubmissionVoteTracker (
    ID int(11) NOT NULL,
    SubmissionID int(11) NOT NULL,
    UserName varchar(50),
    VoteStatus int(11),
    CreationDate timestamp,
    IPAddress varchar(90)
) ENGINE=MyISAM;

CREATE TABLE Subverse (
    Name varchar(20) NOT NULL,
    Title text NOT NULL,
    Description text,
    SideBar text,
    SubmissionText text,
    Language varchar(10),
    `Type` varchar(10) NOT NULL,
    SubmitLinkLabel varchar(50),
    SubmitPostLabel varchar(50),
    SpamFilterLink varchar(10),
    SpamFilterPost varchar(10),
    SpamFilterComment varchar(10),
    IsAdult bit(1) DEFAULT 0 ,
    IsDefaultAllowed bit(1) DEFAULT 1 ,
    IsThumbnailEnabled bit(1) DEFAULT 1 ,
    ExcludeSitewideBans bit(1) DEFAULT 0 ,
    IsTrafficStatsPublic bit(1) DEFAULT 0 ,
    MinutesToHideComments int(11),
    CreationDate timestamp NOT NULL,
    Stylesheet text,
    SubscriberCount int(11),
    IsPrivate bit(1) DEFAULT 0 ,
    IsAuthorizedOnly bit(1) DEFAULT 0 ,
    IsAnonymized bit(1) DEFAULT 0 ,
    LastSubmissionDate timestamp,
    MinCCPForDownVote int(11) DEFAULT 0 NOT NULL,
    IsAdminPrivate bit(1) DEFAULT 0 ,
    IsAdminDisabled bit(1),
    CreatedBy varchar(50)
) ENGINE=MyISAM;

CREATE TABLE SubverseBan (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreatedBy varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL,
    Reason text NOT NULL
) ENGINE=MyISAM;

CREATE TABLE SubverseFlair (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    Label varchar(50),
    CssClass varchar(50)
) ENGINE=MyISAM;

CREATE TABLE SubverseModerator (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    UserName varchar(50) NOT NULL,
    Power int(11) NOT NULL,
    CreatedBy varchar(50),
    CreationDate timestamp
) ENGINE=MyISAM;

CREATE TABLE SubverseSubscription (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    UserName varchar(50) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE UserBadge (
    ID int(11) NOT NULL,
    UserName varchar(50) NOT NULL,
    BadgeID varchar(50) NOT NULL,
    CreationDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE UserBlockedSubverse (
    ID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM;

CREATE TABLE UserBlockedUser (
    ID int(11) NOT NULL,
    BlockUser varchar(50) NOT NULL,
    UserName varchar(50) NOT NULL,
    CreationDate timestamp DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM;

CREATE TABLE UserPreference (
    UserName varchar(50) NOT NULL,
    DisableCSS bit(1) NOT NULL,
    NightMode bit(1) NOT NULL,
    Language varchar(50) NOT NULL,
    OpenInNewWindow bit(1) NOT NULL,
    EnableAdultContent bit(1) NOT NULL,
    DisplayVotes bit(1) NOT NULL,
    DisplaySubscriptions bit(1) DEFAULT 0 ,
    UseSubscriptionsMenu bit(1) DEFAULT 1 ,
    Bio varchar(100),
    Avatar varchar(50),
    DisplayAds bit(1) DEFAULT 0 ,
    DisplayCommentCount int(11),
    HighLightMinutes int(11),
    VanityTitle varchar(50),
    CollapseCommentLimit int(11)
) ENGINE=MyISAM;

CREATE TABLE UserSet (
    ID int(11) NOT NULL,
    Name varchar(20) NOT NULL,
    Description varchar(200) NOT NULL,
    CreatedBy varchar(20) NOT NULL,
    CreationDate timestamp NOT NULL,
    IsPublic bit(1) DEFAULT 1 ,
    SubscriberCount int(11) DEFAULT 1 NOT NULL,
    IsDefault bit(1) DEFAULT 0 
) ENGINE=MyISAM;

CREATE TABLE UserSetList (
    ID int(11) NOT NULL,
    UserSetID int(11) NOT NULL,
    Subverse varchar(20) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE UserSetSubscription (
    ID int(11) NOT NULL,
    UserSetID int(11) NOT NULL,
    `Order` int(11) DEFAULT 0 NOT NULL,
    UserName varchar(20) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE UserVisit (
    ID int(11) NOT NULL,
    SubmissionID int(11) NOT NULL,
    UserName varchar(50) NOT NULL,
    LastVisitDate timestamp NOT NULL
) ENGINE=MyISAM;

CREATE TABLE ViewStatistic (
    SubmissionID int(11) NOT NULL,
    ViewerID varchar(90) NOT NULL
) ENGINE=MyISAM;

ALTER TABLE Ad
    ADD CONSTRAINT Ad_pkey PRIMARY KEY (ID);
ALTER TABLE ApiClient
    ADD CONSTRAINT ApiClient_pkey PRIMARY KEY (ID);
ALTER TABLE ApiCorsPolicy
    ADD CONSTRAINT ApiCorsPolicy_pkey PRIMARY KEY (ID);
ALTER TABLE ApiLog
    ADD CONSTRAINT ApiLog_pkey PRIMARY KEY (ID);
ALTER TABLE ApiPermissionPolicy
    ADD CONSTRAINT ApiPermissionPolicy_pkey PRIMARY KEY (ID);
ALTER TABLE ApiThrottlePolicy
    ADD CONSTRAINT ApiThrottlePolicy_pkey PRIMARY KEY (ID);
ALTER TABLE Badge
    ADD CONSTRAINT Badge_ID_pk PRIMARY KEY (ID);
ALTER TABLE BannedDomain
    ADD CONSTRAINT BannedDomain_pkey PRIMARY KEY (ID);
ALTER TABLE BannedUser
    ADD CONSTRAINT BannedUser_pkey PRIMARY KEY (ID);
ALTER TABLE Comment
    ADD CONSTRAINT Comment_pkey PRIMARY KEY (ID);
ALTER TABLE CommentSaveTracker
    ADD CONSTRAINT CommentSaveTracker_pkey PRIMARY KEY (ID);
ALTER TABLE CommentVoteTracker
    ADD CONSTRAINT CommentVoteTracker_pkey PRIMARY KEY (ID);
ALTER TABLE EventLog
    ADD CONSTRAINT EventLog_pkey PRIMARY KEY (ID);
ALTER TABLE FeaturedSubverse
    ADD CONSTRAINT FeaturedSubverse_pkey PRIMARY KEY (ID);
ALTER TABLE Message
    ADD CONSTRAINT Message_pkey PRIMARY KEY (ID);
ALTER TABLE ModeratorInvitation
    ADD CONSTRAINT ModeratorInvitation_pkey PRIMARY KEY (ID);
ALTER TABLE Submission
    ADD CONSTRAINT Submission_pkey PRIMARY KEY (ID);
ALTER TABLE SubmissionSaveTracker
    ADD CONSTRAINT SubmissionSaveTracker_pkey PRIMARY KEY (ID);
ALTER TABLE SubmissionVoteTracker
    ADD CONSTRAINT SubmissionVoteTracker_pkey PRIMARY KEY (ID);
ALTER TABLE Subverse
    ADD CONSTRAINT Subverse_Name_pk PRIMARY KEY (Name);
ALTER TABLE SubverseBan
    ADD CONSTRAINT SubverseBan_pkey PRIMARY KEY (ID);
ALTER TABLE SubverseFlair
    ADD CONSTRAINT SubverseFlair_pkey PRIMARY KEY (ID);
ALTER TABLE SubverseModerator
    ADD CONSTRAINT SubverseModerator_pkey PRIMARY KEY (ID);
ALTER TABLE SubverseSubscription
    ADD CONSTRAINT SubverseSubscription_pkey PRIMARY KEY (ID);
ALTER TABLE UserBadge
    ADD CONSTRAINT UserBadge_pkey PRIMARY KEY (ID);
ALTER TABLE UserBlockedSubverse
    ADD CONSTRAINT UserBlockedSubverse_pkey PRIMARY KEY (ID);
ALTER TABLE UserBlockedUser
    ADD CONSTRAINT UserBlockedUser_pkey PRIMARY KEY (ID);
ALTER TABLE UserSet
    ADD CONSTRAINT UserSet_pkey PRIMARY KEY (ID);
ALTER TABLE UserSetList
    ADD CONSTRAINT UserSetList_pkey PRIMARY KEY (ID);
ALTER TABLE UserSetSubscription
    ADD CONSTRAINT UserSetSubscription_pkey PRIMARY KEY (ID);
ALTER TABLE UserVisit
    ADD CONSTRAINT UserVisit_pkey PRIMARY KEY (ID);

CREATE DATABASE IF NOT EXISTS `voat_users` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `voat_users`;

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE IF NOT EXISTS `applications` (
  `ApplicationId` int(11) NOT NULL AUTO_INCREMENT,
  `ApplicationName` varchar(256) NOT NULL,
  `LoweredApplicationName` varchar(256) NOT NULL,
  `Description` varchar(256) NOT NULL,
  PRIMARY KEY (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aspnetroles`
--

DROP TABLE IF EXISTS `aspnetroles`;
CREATE TABLE IF NOT EXISTS `aspnetroles` (
  `Id` varchar(128) NOT NULL,
  `Name` varchar(4096) NOT NULL,
  `baxt` int(11) NOT NULL,
  `saxt` int(11) NOT NULL,
  PRIMARY KEY (`Id`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aspnetuserclaims`
--

DROP TABLE IF EXISTS `aspnetuserclaims`;
CREATE TABLE IF NOT EXISTS `aspnetuserclaims` (
  `Id` int(11) NOT NULL,
  `ClaimType` varchar(4096) NOT NULL,
  `ClaimValue` varchar(4096) NOT NULL,
  `UserId` varchar(128) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aspnetuserlogins`
--

DROP TABLE IF EXISTS `aspnetuserlogins`;
CREATE TABLE IF NOT EXISTS `aspnetuserlogins` (
  `UserId` varchar(128) NOT NULL,
  `LoginProvider` varchar(128) NOT NULL,
  `ProviderKey` varchar(128) NOT NULL,
  PRIMARY KEY (`UserId`,`LoginProvider`,`ProviderKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aspnetuserroles`
--

DROP TABLE IF EXISTS `aspnetuserroles`;
CREATE TABLE IF NOT EXISTS `aspnetuserroles` (
  `UserId` varchar(128) NOT NULL,
  `RoleId` varchar(128) NOT NULL,
  PRIMARY KEY (`UserId`,`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
CREATE TABLE IF NOT EXISTS `aspnetusers` (
  `Id` varchar(128) NOT NULL,
  `UserName` varchar(800) NOT NULL,
  `PasswordHash` varchar(4096) NOT NULL,
  `SecurityStamp` varchar(4096) NOT NULL,
  `Email` varchar(4096) NOT NULL,
  `IsConfirmed` tinyint(1) NOT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PhoneNumber` char(10) NOT NULL,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEndDateUtc` datetime NOT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int(11) NOT NULL,
  `RegistrationDateTime` datetime NOT NULL,
  `RecoveryQuestion` varchar(1024) NOT NULL,
  `Answer` varchar(1024) NOT NULL,
  `Partner` tinyint(1) NOT NULL,
  `LastLoginFromIp` varchar(50) NOT NULL,
  `LastLoginDateTime` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

DROP TABLE IF EXISTS `membership`;
CREATE TABLE IF NOT EXISTS `membership` (
  `ApplicationId` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` int(11) NOT NULL,
  `Password` varchar(128) NOT NULL,
  `PasswordFormat` int(11) NOT NULL,
  `PasswordSalt` varchar(128) NOT NULL,
  `MobilePIN` varchar(16) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `LoweredEmail` varchar(256) NOT NULL,
  `PasswordQuestion` varchar(256) NOT NULL,
  `PasswordAnswer` varchar(128) NOT NULL,
  `IsApproved` tinyint(1) NOT NULL,
  `IsLockedOut` tinyint(1) NOT NULL,
  `CreateDate` datetime NOT NULL,
  `LastLoginDate` datetime NOT NULL,
  `LastPasswordChangedDate` datetime NOT NULL,
  `LastLockoutDate` datetime NOT NULL,
  `FailedPasswordAttemptCount` int(11) NOT NULL,
  `FailedPasswordAttemptWindowStart` datetime NOT NULL,
  `FailedPasswordAnswerAttemptCount` int(11) NOT NULL,
  `FailedPasswordAnswerAttemptWindowStart` datetime NOT NULL,
  `Comment` text,
  PRIMARY KEY (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `paths`
--

DROP TABLE IF EXISTS `paths`;
CREATE TABLE IF NOT EXISTS `paths` (
  `ApplicationId` int(11) NOT NULL AUTO_INCREMENT,
  `PathId` int(11) NOT NULL,
  `Path` varchar(256) NOT NULL,
  `LoweredPath` varchar(256) NOT NULL,
  PRIMARY KEY (`ApplicationId`),
  UNIQUE KEY `PathId` (`PathId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `personalizationallusers`
--

DROP TABLE IF EXISTS `personalizationallusers`;
CREATE TABLE IF NOT EXISTS `personalizationallusers` (
  `PathId` int(11) NOT NULL AUTO_INCREMENT,
  `PageSettings` blob NOT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  PRIMARY KEY (`PathId`),
  UNIQUE KEY `PathId` (`PathId`),
  UNIQUE KEY `PathId_2` (`PathId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `personalizationperuser`
--

DROP TABLE IF EXISTS `personalizationperuser`;
CREATE TABLE IF NOT EXISTS `personalizationperuser` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PathId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `PageSettings` blob NOT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `PathId` (`PathId`),
  UNIQUE KEY `UserId` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE IF NOT EXISTS `profile` (
  `UserId` int(11) NOT NULL,
  `PropertyNames` text NOT NULL,
  `PropertyValuesString` text NOT NULL,
  `PropertyValuesBinary` blob NOT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `ApplicationId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `RoleName` varchar(256) NOT NULL,
  `LoweredRoleName` varchar(256) NOT NULL,
  `Description` varchar(256) NOT NULL,
  PRIMARY KEY (`RoleId`),
  UNIQUE KEY `ApplicationId` (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `schemaversions`
--

DROP TABLE IF EXISTS `schemaversions`;
CREATE TABLE IF NOT EXISTS `schemaversions` (
  `Feature` varchar(128) NOT NULL,
  `CompatibleSchemaVersion` varchar(128) NOT NULL,
  `IsCurrentVersion` tinyint(1) NOT NULL,
  PRIMARY KEY (`Feature`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `SessionId` varchar(88) NOT NULL,
  `Created` datetime NOT NULL,
  `Expires` datetime NOT NULL,
  `LockDate` datetime NOT NULL,
  `LockCookie` int(11) NOT NULL,
  `Locked` tinyint(1) NOT NULL,
  `SessionItem` blob NOT NULL,
  `Flags` int(11) NOT NULL,
  `Timeout` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ApplicationId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  `LoweredUserName` varchar(256) NOT NULL,
  `MobileAlias` varchar(16) NOT NULL,
  `IsAnonymous` tinyint(1) NOT NULL,
  `LastActivityDate` datetime NOT NULL,
  PRIMARY KEY (`UserId`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `usersinroles`
--

DROP TABLE IF EXISTS `usersinroles`;
CREATE TABLE IF NOT EXISTS `usersinroles` (
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `naxt` int(11) NOT NULL,
  `baxt` int(11) NOT NULL,
  PRIMARY KEY (`RoleId`),
  UNIQUE KEY `UserId` (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_applications`
--

DROP TABLE IF EXISTS `vw_aspnet_applications`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_applications` (
  `ApplicationName` varchar(256) NOT NULL,
  `LoweredApplicationName` varchar(256) NOT NULL,
  `ApplicationId` int(11) NOT NULL,
  `Description` varchar(256) NOT NULL,
  PRIMARY KEY (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_membershipusers`
--

DROP TABLE IF EXISTS `vw_aspnet_membershipusers`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_membershipusers` (
  `UserId` int(11) NOT NULL,
  `PasswordFormat` int(11) NOT NULL,
  `MobilePIN` varchar(16) NOT NULL,
  `Email` varchar(256) NOT NULL,
  `LoweredEmail` varchar(256) NOT NULL,
  `PasswordQuestion` varchar(256) NOT NULL,
  `PasswordAnswer` varchar(256) NOT NULL,
  `IsApproved` tinyint(1) NOT NULL,
  `IsLockedOut` tinyint(1) NOT NULL,
  `CreateDate` datetime NOT NULL,
  `LastLoginDate` datetime NOT NULL,
  `LastPasswordChangedDate` datetime NOT NULL,
  `LastLockoutDate` datetime NOT NULL,
  `FailedPasswordAttemptCount` int(11) NOT NULL,
  `FailedPasswordAttemptWindowStart` datetime NOT NULL,
  `FailedPasswordAnswerAttemptCount` int(11) NOT NULL,
  `FailedPasswordAnswerAttemptWindowStart` datetime NOT NULL,
  `Comment` text NOT NULL,
  `ApplicationId` int(11) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  `MobileAlias` varchar(16) NOT NULL,
  `IsAnonymous` tinyint(1) NOT NULL,
  `LastActivityDate` datetime NOT NULL,
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `ApplicationId` (`ApplicationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_profiles`
--

DROP TABLE IF EXISTS `vw_aspnet_profiles`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_profiles` (
  `UserId` int(11) NOT NULL,
  `LastUpdatedDate` int(11) NOT NULL,
  `DataSize` datetime NOT NULL,
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `LastUpdatedDate` (`LastUpdatedDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_roles`
--

DROP TABLE IF EXISTS `vw_aspnet_roles`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_roles` (
  `ApplicationId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `RoleName` varchar(256) NOT NULL,
  `LoweredRoleName` varchar(256) NOT NULL,
  `Description` varchar(256) NOT NULL,
  PRIMARY KEY (`ApplicationId`,`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_users`
--

DROP TABLE IF EXISTS `vw_aspnet_users`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_users` (
  `ApplicationId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  `LoweredUserName` varchar(256) NOT NULL,
  `MobileAlias` varchar(16) NOT NULL,
  `IsAnonymous` tinyint(1) NOT NULL,
  `LastActivityDate` datetime NOT NULL,
  UNIQUE KEY `ApplicationId` (`ApplicationId`,`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_usersinroles`
--

DROP TABLE IF EXISTS `vw_aspnet_usersinroles`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_usersinroles` (
  `UserId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  PRIMARY KEY (`UserId`,`RoleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_webpartstate_paths`
--

DROP TABLE IF EXISTS `vw_aspnet_webpartstate_paths`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_webpartstate_paths` (
  `ApplicationId` int(11) NOT NULL,
  `PathId` int(11) NOT NULL,
  `Path` varchar(256) NOT NULL,
  `LoweredPath` varchar(256) NOT NULL,
  PRIMARY KEY (`ApplicationId`,`PathId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_webpartstate_shared`
--

DROP TABLE IF EXISTS `vw_aspnet_webpartstate_shared`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_webpartstate_shared` (
  `PathId` int(11) NOT NULL,
  `DataSize` int(11) DEFAULT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  PRIMARY KEY (`PathId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `vw_aspnet_webpartstate_user`
--

DROP TABLE IF EXISTS `vw_aspnet_webpartstate_user`;
CREATE TABLE IF NOT EXISTS `vw_aspnet_webpartstate_user` (
  `PathId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `DataSize` int(11) DEFAULT NULL,
  `LastUpdatedDate` datetime NOT NULL,
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `PathId` (`PathId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `webevent_events`
--

DROP TABLE IF EXISTS `webevent_events`;
CREATE TABLE IF NOT EXISTS `webevent_events` (
  `EventId` char(32) NOT NULL,
  `EventTimeUtc` datetime NOT NULL,
  `EventTime` datetime NOT NULL,
  `EventType` varchar(256) NOT NULL,
  `EventSequence` decimal(19,0) NOT NULL,
  `EventOccurrence` decimal(19,0) NOT NULL,
  `EventCode` int(11) NOT NULL,
  `EventDetailCode` int(11) NOT NULL,
  `Message` varchar(1024) NOT NULL,
  `ApplicationPath` varchar(256) NOT NULL,
  `ApplicationVirtualPath` varchar(256) NOT NULL,
  `MachineName` varchar(256) NOT NULL,
  `RequestUrl` varchar(1024) NOT NULL,
  `ExceptionType` varchar(256) NOT NULL,
  `Details` text NOT NULL,
  PRIMARY KEY (`EventId`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
