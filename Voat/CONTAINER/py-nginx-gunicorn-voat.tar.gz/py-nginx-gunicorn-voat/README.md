# getting started with python docker
nginx, python, gunicorn, flask docker getting started